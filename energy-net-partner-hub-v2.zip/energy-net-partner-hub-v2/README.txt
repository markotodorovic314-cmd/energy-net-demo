ENERGY NET PARTNER HUB — DEMO V2

1. Otvorite index.html u Chrome/Edge browseru.
2. Gornji switch u levom meniju menja Partner / Admin prikaz.
3. Predloženi demo flow:
   Partner → Katalog → otvori proizvod → dodaj u korpu → Pošalji porudžbinu
   Admin → Porudžbine → otvori novu porudžbinu → Odobri i pošalji u ERP
   Admin → ERP / WMS sync
   Admin → Proizvodi → + Dodaj proizvod
4. Sve cene, zalihe, partneri, porudžbine i poslovni pokazatelji su demo podaci.
5. Nazivi kategorija i deo naziva/specifikacija proizvoda oslanjaju se na javno dostupne Energy Net kataloge.

Fajl je standalone: nema instalacije niti servera.
